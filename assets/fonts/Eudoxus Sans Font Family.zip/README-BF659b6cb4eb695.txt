# Eudoxus Sans
<img src="https://github.com/stijndevries/Eudoxus-Sans/blob/main/images/Eudoxus-of-Cnidus-Social-image.png?raw=true" width="600">
This simple geometric font is named after the Greek mathematician Eudoxus of Cnidus. It is based on +Jakarta Sans by tokotype.
